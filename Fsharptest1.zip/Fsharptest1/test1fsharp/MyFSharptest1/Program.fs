﻿let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]


salaries |> List.iter (printfn "%d")

printfn""

let highIncomeSalaries = salaries |> List.filter (fun x -> x > 100000)
highIncomeSalaries |> List.iter (printfn "High income salaries: %d")

printfn""
let calculateTax s =
    match s with
    | _ when s <= 49020 -> float s * 0.15
    | _ when s <= 98040 -> float s * 0.205
    | _ when s <= 151978 -> float s * 0.26
    | _ when s <= 216511 -> float s * 0.29
    | _ -> float s * 0.33

let taxableSalaries = salaries |> List.map (fun s -> (s, calculateTax s))


taxableSalaries |> List.iter (fun (original, taxed) -> printfn "Taxable amount of %d = %.2f" original taxed)
printfn""
let filteredSalaries = salaries |> List.filter (fun s -> s < 49020)

filteredSalaries |> List.iter (printfn "Filtered salary: %d")

let updatedSalaries = filteredSalaries |> List.map (fun s -> s + 20000)

updatedSalaries |> List.iter (printfn "Updated salary: %d")
printfn""
let salariesInRange = salaries |> List.filter (fun s -> s >= 50000 && s <= 100000)

salariesInRange |> List.iter (printfn "Salary in range: %d")

let totalSum = salariesInRange |> List.fold (fun acc s -> acc + s) 0

printfn "Total sum of salaries: %d" totalSum

printfn""

let sumOfMultiplesOfp (n: int) =
    let rec helper (current: int) (acc: int) =
        if current <= 0 then acc
        else helper (current - 3) (acc + current)
    helper n 0

let result = sumOfMultiplesOfp 9
printfn "The sum of all multiples of 3 up to 9 is %d" result